// Adiciona um ouvinte de evento para o envio do formulário
document
  .getElementById("form-animais")
  .addEventListener("submit", function (e) {
    e.preventDefault(); // Impede que a página recarregue ao enviar o formulário

    // Captura os valores dos campos do formulário
    const nome = document.getElementById("nome").value;
    const especie = document.getElementById("especie").value;
    const idade = document.getElementById("idade").value;
    const habitat = document.getElementById("habitat").value;

    // Verifica se todos os campos foram preenchidos
    if (!nome || !especie || !idade || !habitat) {
      alert("Preencha todos os campos.");
      return; // Interrompe o cadastro se algum campo estiver vazio
    }

    // Cria um novo objeto com os dados do animal
    const novoAnimal = { nome, especie, idade, habitat };

    // Recupera a lista atual de animais do localStorage (ou inicia um array vazio)
    let animais = JSON.parse(localStorage.getItem("animais")) || [];

    // Adiciona o novo animal à lista
    animais.push(novoAnimal);

    // Salva a lista atualizada no localStorage
    localStorage.setItem("animais", JSON.stringify(animais));

    // Limpa o formulário após o envio
    document.getElementById("form-animais").reset();

    // Exibe uma mensagem de sucesso
    alert("Animal cadastrado com sucesso!");

    // Atualiza a lista de animais exibida na página
    listarAnimais();
  });

// Função que exibe a lista de animais cadastrados na tela
function listarAnimais() {
  const container = document.getElementById("lista-animais");
  container.innerHTML = ""; // Limpa o conteúdo anterior da lista

  // Recupera os animais salvos no localStorage
  const animais = JSON.parse(localStorage.getItem("animais")) || [];

  // Se não houver animais, exibe uma mensagem
  if (animais.length === 0) {
    container.innerHTML = "<p>Nenhum animal cadastrado.</p>";
    return;
  }

  // Para cada animal, cria um bloco de informações na tela
  animais.forEach((animal) => {
    const div = document.createElement("div");
    div.className = "animal"; // Adiciona uma classe CSS (caso queira estilizar)
    div.innerHTML = `<strong>Animal: ${animal.nome}</strong><br>Espécie: ${animal.especie}
    <strong><br>Idade: ${animal.idade}</strong><br>Habitat: ${animal.habitat}`; // Obs: havia uma tag <strong> não fechada, corrigi
    container.appendChild(div); // Adiciona o elemento à lista na página
  });
}

// Quando a página carregar, chama a função para listar os animais salvos
window.addEventListener("DOMContentLoaded", listarAnimais);
